﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_SYBD
{
    internal class DB
    {
    //    MySqlConnection connectionAdmin = new MySqlConnection("server=localhost;port=3306;username=root;password=root;database=deliverydb;");
        MySqlConnection connection = new MySqlConnection("server=localhost;port=3306;username=root;password=root;database=deliverydb;Allow User Variables=True;");
        //public void openConnectionAdmin()
        //{
        //    if(connectionAdmin.State == System.Data.ConnectionState.Closed)
        //    { connectionAdmin.Open(); }
        //}

        
            public void openConnection()
        {
            if (connection.State == System.Data.ConnectionState.Closed)
            { connection.Open(); }
        }


        //public void closeConnectionAdmin()
        //{
        //    if (connectionAdmin.State == System.Data.ConnectionState.Open)
        //    { connectionAdmin.Close(); }
        //}

        public void closeConnection()
        {
            if (connection.State == System.Data.ConnectionState.Open)
            { connection.Close(); }
        }

        //public MySqlConnection getConnectionAdmin()
        //{
        //    return connectionAdmin;
        //}

        public MySqlConnection getConnection()
        {
            return connection;
        }
    }
}
