﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab_SYBD
{
    public partial class ChangeUserData : Form
    {
        public ChangeUserData()
        {
            InitializeComponent();
           
        }

        public static string cur_name, cur_surname, cur_phone, cur_district, cur_street, cur_house, cur_apartment;

        private void ChangeUserData_Load(object sender, EventArgs e)
        {
            
            string currentUser = AuthorizationForm.currentLogin;
            
            DB db = new DB();
            
            MySqlCommand commandName = new MySqlCommand("CALL `cmndName`(@ul1);", db.getConnection());
            MySqlCommand commandSurname = new MySqlCommand("CALL `cmndSur`(@ul2);", db.getConnection());
            MySqlCommand commandPhone = new MySqlCommand("CALL `cmndPhone`(@ul3);", db.getConnection());
            MySqlCommand commandDistrict = new MySqlCommand("CALL `cmndDistrict`(@ul4);", db.getConnection());
            MySqlCommand commandStreet = new MySqlCommand("CALL `cmndStreet`(@ul5);", db.getConnection());
            MySqlCommand commandHouse = new MySqlCommand("CALL `cmndHouse`(@ul6);", db.getConnection());
            MySqlCommand commandApartment = new MySqlCommand("CALL `cmndApartment`(@ul7);", db.getConnection());

            commandName.Parameters.Add("@uL1", MySqlDbType.VarChar).Value = currentUser;
            commandSurname.Parameters.Add("@uL2", MySqlDbType.VarChar).Value = currentUser;
            commandPhone.Parameters.Add("@uL3", MySqlDbType.VarChar).Value = currentUser;
            commandDistrict.Parameters.Add("@uL4", MySqlDbType.VarChar).Value = currentUser;
            commandStreet.Parameters.Add("@uL5", MySqlDbType.VarChar).Value = currentUser;
            commandHouse.Parameters.Add("@uL6", MySqlDbType.VarChar).Value = currentUser;
            commandApartment.Parameters.Add("@uL7", MySqlDbType.VarChar).Value = currentUser;
            
            db.openConnection();
            nameField.Text = commandName.ExecuteScalar().ToString();
            cur_name = nameField.Text;

            surnameField.Text = commandSurname.ExecuteScalar().ToString();
            cur_surname = surnameField.Text;
            
            phoneField.Text =  commandPhone.ExecuteScalar().ToString();
            cur_phone = phoneField.Text;
            
            DistrictField.Text = commandDistrict.ExecuteScalar().ToString();
            cur_district = DistrictField.Text;
            
            streetField.Text = commandStreet.ExecuteScalar().ToString();
            cur_street = streetField.Text;
            
            houseField.Text = commandHouse.ExecuteScalar().ToString();
            cur_house = houseField.Text;
            
            apartmentField.Text = commandApartment.ExecuteScalar().ToString();
            cur_apartment = apartmentField.Text;
            db.closeConnection();
        }

        private void ChangeUserData_FormClosed(object sender, FormClosedEventArgs e)
        {
            //if (saved)
            //{
            //    this.Hide();
            //    LoggedUserForm frm = new LoggedUserForm();
            //    frm.Show();
            //}
            //else
            //{
            //    DialogResult result = MessageBox.Show
            //        ("У вас есть несохранённые данные. Вы действительно хотите выйти?", "Выход из приложения",
            //        MessageBoxButtons.YesNo);

            //    if (result == DialogResult.Yes)
            //    {
                    Application.Exit();
                //}
                //this.Hide();
            //}
            
        }

        public Boolean saved = true;

        private void BackToMain_Click(object sender, EventArgs e)
        {
            if (saved)
            {
                this.Hide();
                LoggedUserForm frm = new LoggedUserForm();
                frm.Show();
                
            }
            else
            {
                DialogResult result = MessageBox.Show
                    ("У вас есть несохранённые данные. Вы действительно хотите выйти?", "Выход в главное меню",
                    MessageBoxButtons.YesNo);

                if (result == DialogResult.Yes)
                {
                    this.Hide();
                    LoggedUserForm frm = new LoggedUserForm();
                    frm.Show();
                }
                if (result == DialogResult.No) 
                {
                    this.TopMost = true;
                }
            }
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            DB db = new DB();

            MySqlCommand commandChangeData = new MySqlCommand("CALL `cmndChangeData`(@uN, @uSur, @uPh, @uD, @uSt, @uH, @uA, @uL);", db.getConnection());

            if (!nameField.MaskCompleted) MessageBox.Show("Поле 'Имя' обязательно для заполнения");
            else if (!phoneField.MaskCompleted) MessageBox.Show("Поле 'Номер телефона' обязательно для заполнения");
            else if(!streetField.MaskCompleted) MessageBox.Show("Поле 'Улица' обязательно для заполнения");
            else if(!houseField.MaskCompleted) MessageBox.Show("Поле 'Дом' обязательно для заполнения");
            else
            {
                commandChangeData.Parameters.Add("@uN", MySqlDbType.VarChar).Value = nameField.Text;
                
                commandChangeData.Parameters.Add("@uSur", MySqlDbType.VarChar).Value = surnameField.Text;

                commandChangeData.Parameters.Add("@uPh", MySqlDbType.VarChar).Value = phoneField.Text;
                
                commandChangeData.Parameters.Add("@uD", MySqlDbType.VarChar).Value = DistrictField.Text;

                commandChangeData.Parameters.Add("@uSt", MySqlDbType.VarChar).Value = streetField.Text;
                
                commandChangeData.Parameters.Add("@uH", MySqlDbType.VarChar).Value = houseField.Text;

                commandChangeData.Parameters.Add("@uA", MySqlDbType.VarChar).Value = apartmentField.Text;

                commandChangeData.Parameters.Add("@uL", MySqlDbType.VarChar).Value = AuthorizationForm.currentLogin;


                db.openConnection();


                if (commandChangeData.ExecuteNonQuery() == 1)
                    MessageBox.Show("Данные были сохранены!");
                else MessageBox.Show("Данные не сохранены!", "Ошибка");

                db.closeConnection();

                saved = true;
            }
            
        }

        private void nameField_TextChanged(object sender, EventArgs e)
        {
            if (nameField.Text == cur_name) saved = true;
            else saved = false;
        }

        private void surnameField_TextChanged(object sender, EventArgs e)
        {
            if (surnameField.Text == cur_surname) saved = true;
            else saved = false;
        }

        private void phoneField_TextChanged(object sender, EventArgs e)
        {
            if (phoneField.Text == cur_phone) saved = true;
            else saved = false;
        }

        private void DistrictField_TextChanged(object sender, EventArgs e)
        {
            if (DistrictField.Text == cur_district) saved = true;
            else saved = false;
        }

        private void streetField_TextChanged(object sender, EventArgs e)
        {
            if (streetField.Text == cur_street) saved = true;
            else saved = false;
        }

        private void houseField_TextChanged(object sender, EventArgs e)
        {
            if (houseField.Text == cur_house) saved = true;
            else saved = false;
        }

        private void apartmentField_TextChanged(object sender, EventArgs e)
        {
            if (apartmentField.Text == cur_apartment) saved = true;
            else saved = false;
        }
    }
}
