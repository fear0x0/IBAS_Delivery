﻿namespace lab_SYBD
{
    partial class ChangeUserData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChangeUserData));
            this.label1 = new System.Windows.Forms.Label();
            this.DistrictField = new System.Windows.Forms.TextBox();
            this.surnameField = new System.Windows.Forms.TextBox();
            this.apartmentField = new System.Windows.Forms.TextBox();
            this.labelSurname = new System.Windows.Forms.Label();
            this.labelPhone = new System.Windows.Forms.Label();
            this.labelDistrict = new System.Windows.Forms.Label();
            this.labelStreet = new System.Windows.Forms.Label();
            this.labelHouse = new System.Windows.Forms.Label();
            this.labelApartment = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.SaveButton = new System.Windows.Forms.Button();
            this.BackToMain = new System.Windows.Forms.Label();
            this.phoneField = new System.Windows.Forms.MaskedTextBox();
            this.nameField = new System.Windows.Forms.MaskedTextBox();
            this.streetField = new System.Windows.Forms.MaskedTextBox();
            this.houseField = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(161, 33);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(285, 32);
            this.label1.TabIndex = 17;
            this.label1.Text = "Изменение данных";
            // 
            // DistrictField
            // 
            this.DistrictField.Location = new System.Drawing.Point(211, 226);
            this.DistrictField.Name = "DistrictField";
            this.DistrictField.Size = new System.Drawing.Size(276, 22);
            this.DistrictField.TabIndex = 19;
            this.DistrictField.TextChanged += new System.EventHandler(this.DistrictField_TextChanged);
            // 
            // surnameField
            // 
            this.surnameField.Location = new System.Drawing.Point(211, 134);
            this.surnameField.Name = "surnameField";
            this.surnameField.Size = new System.Drawing.Size(276, 22);
            this.surnameField.TabIndex = 21;
            this.surnameField.TextChanged += new System.EventHandler(this.surnameField_TextChanged);
            // 
            // apartmentField
            // 
            this.apartmentField.Location = new System.Drawing.Point(211, 359);
            this.apartmentField.Name = "apartmentField";
            this.apartmentField.Size = new System.Drawing.Size(276, 22);
            this.apartmentField.TabIndex = 23;
            this.apartmentField.TextChanged += new System.EventHandler(this.apartmentField_TextChanged);
            // 
            // labelSurname
            // 
            this.labelSurname.AutoSize = true;
            this.labelSurname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelSurname.Location = new System.Drawing.Point(88, 130);
            this.labelSurname.Name = "labelSurname";
            this.labelSurname.Size = new System.Drawing.Size(103, 25);
            this.labelSurname.TabIndex = 31;
            this.labelSurname.Text = "Фамилия";
            // 
            // labelPhone
            // 
            this.labelPhone.AutoSize = true;
            this.labelPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelPhone.Location = new System.Drawing.Point(14, 178);
            this.labelPhone.Name = "labelPhone";
            this.labelPhone.Size = new System.Drawing.Size(185, 25);
            this.labelPhone.TabIndex = 30;
            this.labelPhone.Text = "*Номер телефона";
            // 
            // labelDistrict
            // 
            this.labelDistrict.AutoSize = true;
            this.labelDistrict.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelDistrict.Location = new System.Drawing.Point(124, 222);
            this.labelDistrict.Name = "labelDistrict";
            this.labelDistrict.Size = new System.Drawing.Size(67, 25);
            this.labelDistrict.TabIndex = 29;
            this.labelDistrict.Text = "Район";
            // 
            // labelStreet
            // 
            this.labelStreet.AutoSize = true;
            this.labelStreet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelStreet.Location = new System.Drawing.Point(122, 268);
            this.labelStreet.Name = "labelStreet";
            this.labelStreet.Size = new System.Drawing.Size(77, 25);
            this.labelStreet.TabIndex = 28;
            this.labelStreet.Text = "*Улица";
            // 
            // labelHouse
            // 
            this.labelHouse.AutoSize = true;
            this.labelHouse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelHouse.Location = new System.Drawing.Point(134, 310);
            this.labelHouse.Name = "labelHouse";
            this.labelHouse.Size = new System.Drawing.Size(65, 25);
            this.labelHouse.TabIndex = 27;
            this.labelHouse.Text = "*Дом";
            // 
            // labelApartment
            // 
            this.labelApartment.AutoSize = true;
            this.labelApartment.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelApartment.Location = new System.Drawing.Point(92, 355);
            this.labelApartment.Name = "labelApartment";
            this.labelApartment.Size = new System.Drawing.Size(99, 25);
            this.labelApartment.TabIndex = 26;
            this.labelApartment.Text = "Квартира";
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(137, 88);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(62, 25);
            this.labelName.TabIndex = 25;
            this.labelName.Text = "*Имя";
            // 
            // SaveButton
            // 
            this.SaveButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SaveButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SaveButton.Location = new System.Drawing.Point(235, 406);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(125, 35);
            this.SaveButton.TabIndex = 32;
            this.SaveButton.Text = "Сохранить";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // BackToMain
            // 
            this.BackToMain.AutoSize = true;
            this.BackToMain.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BackToMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BackToMain.Location = new System.Drawing.Point(13, 13);
            this.BackToMain.Name = "BackToMain";
            this.BackToMain.Size = new System.Drawing.Size(37, 20);
            this.BackToMain.TabIndex = 33;
            this.BackToMain.Text = "<---";
            this.BackToMain.Click += new System.EventHandler(this.BackToMain_Click);
            // 
            // phoneField
            // 
            this.phoneField.Location = new System.Drawing.Point(211, 178);
            this.phoneField.Mask = "+0 000 000 0000";
            this.phoneField.Name = "phoneField";
            this.phoneField.Size = new System.Drawing.Size(276, 22);
            this.phoneField.TabIndex = 34;
            // 
            // nameField
            // 
            this.nameField.Location = new System.Drawing.Point(206, 90);
            this.nameField.Mask = "L??????????????????";
            this.nameField.Name = "nameField";
            this.nameField.Size = new System.Drawing.Size(281, 22);
            this.nameField.TabIndex = 35;
            // 
            // streetField
            // 
            this.streetField.Location = new System.Drawing.Point(211, 272);
            this.streetField.Mask = "Aaaaaaaaaaaaaaaaaaaaaa";
            this.streetField.Name = "streetField";
            this.streetField.Size = new System.Drawing.Size(276, 22);
            this.streetField.TabIndex = 36;
            // 
            // houseField
            // 
            this.houseField.Location = new System.Drawing.Point(211, 312);
            this.houseField.Mask = "Aaaaaaaaaaaa";
            this.houseField.Name = "houseField";
            this.houseField.Size = new System.Drawing.Size(276, 22);
            this.houseField.TabIndex = 37;
            // 
            // ChangeUserData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(590, 453);
            this.Controls.Add(this.houseField);
            this.Controls.Add(this.streetField);
            this.Controls.Add(this.nameField);
            this.Controls.Add(this.phoneField);
            this.Controls.Add(this.BackToMain);
            this.Controls.Add(this.SaveButton);
            this.Controls.Add(this.labelSurname);
            this.Controls.Add(this.labelPhone);
            this.Controls.Add(this.labelDistrict);
            this.Controls.Add(this.labelStreet);
            this.Controls.Add(this.labelHouse);
            this.Controls.Add(this.labelApartment);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.apartmentField);
            this.Controls.Add(this.surnameField);
            this.Controls.Add(this.DistrictField);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ChangeUserData";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Go.Доставка";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ChangeUserData_FormClosed);
            this.Load += new System.EventHandler(this.ChangeUserData_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox DistrictField;
        private System.Windows.Forms.TextBox surnameField;
        private System.Windows.Forms.TextBox apartmentField;
        private System.Windows.Forms.Label labelSurname;
        private System.Windows.Forms.Label labelPhone;
        private System.Windows.Forms.Label labelDistrict;
        private System.Windows.Forms.Label labelStreet;
        private System.Windows.Forms.Label labelHouse;
        private System.Windows.Forms.Label labelApartment;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.Label BackToMain;
        private System.Windows.Forms.MaskedTextBox phoneField;
        private System.Windows.Forms.MaskedTextBox nameField;
        private System.Windows.Forms.MaskedTextBox streetField;
        private System.Windows.Forms.MaskedTextBox houseField;
    }
}