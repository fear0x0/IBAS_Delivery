﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace lab_SYBD
{
    public partial class LoggedUserForm : Form
    {
        public LoggedUserForm()
        {
            InitializeComponent();
        }

        private void LoggedUserForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }


        private void LoggedUserForm_Load(object sender, EventArgs e)
        {
            string currentUser = AuthorizationForm.currentLogin;

            WelcomeLable.Text = $"Приветствуем Вас, {currentUser}";
            
            
            DB db = new DB();

            MySqlCommand commandName = new MySqlCommand("CALL `cmndName`(@ul1);", db.getConnection());
            MySqlCommand commandSurname = new MySqlCommand("CALL `cmndSur`(@ul2);", db.getConnection());
            MySqlCommand commandPhone = new MySqlCommand("CALL `cmndPhone`(@ul3);", db.getConnection());
            MySqlCommand commandDistrict = new MySqlCommand("CALL `cmndDistrict`(@ul4);", db.getConnection());
            MySqlCommand commandStreet = new MySqlCommand("CALL `cmndStreet`(@ul5);", db.getConnection());
            MySqlCommand commandHouse = new MySqlCommand("CALL `cmndHouse`(@ul6);", db.getConnection());
            MySqlCommand commandApartment = new MySqlCommand("CALL `cmndApartment`(@ul7);", db.getConnection());
            MySqlCommand commandLastOrder = new MySqlCommand("CALL `cmndLastOrder`(@ul8);", db.getConnection());

            
            string res = "Ваш последний заказ:\n";

            commandName.Parameters.Add("@uL1", MySqlDbType.VarChar).Value = currentUser;
            commandSurname.Parameters.Add("@uL2", MySqlDbType.VarChar).Value = currentUser;
            commandPhone.Parameters.Add("@uL3", MySqlDbType.VarChar).Value = currentUser;
            commandDistrict.Parameters.Add("@uL4", MySqlDbType.VarChar).Value = currentUser;
            commandStreet.Parameters.Add("@uL5", MySqlDbType.VarChar).Value = currentUser;
            commandHouse.Parameters.Add("@uL6", MySqlDbType.VarChar).Value = currentUser;
            commandApartment.Parameters.Add("@uL7", MySqlDbType.VarChar).Value = currentUser;
            commandLastOrder.Parameters.Add("@uL8", MySqlDbType.VarChar).Value = currentUser;

            db.openConnection();


            labelName.Text = "Имя: " + commandName.ExecuteScalar().ToString();
            labelSurname.Text = "Фамилия: " + commandSurname.ExecuteScalar().ToString();
            labelPhone.Text = "Номер телефона: " + commandPhone.ExecuteScalar().ToString();
            labelDistrict.Text = "Район: " + commandDistrict.ExecuteScalar().ToString();
            labelStreet.Text = "Улица: " + commandStreet.ExecuteScalar().ToString();
            labelHouse.Text = "Дом: " + commandHouse.ExecuteScalar().ToString();
            labelApartment.Text = "Квартира: " + commandApartment.ExecuteScalar().ToString();

            MySqlDataReader rdr = commandLastOrder.ExecuteReader();
            while (rdr.Read())
            {
                res += rdr["menu_name"] + " " + rdr["amount"] + "шт." + "\n";
            }
            rdr.Close();

            LastOrder.Text = res;
            
            db.closeConnection();
        }

        private void ExitFromAcc_Click(object sender, EventArgs e)
        {
            this.Hide();
            AuthorizationForm frm = new AuthorizationForm();
            frm.Show();
        }

        private void ChangeData_Click(object sender, EventArgs e)
        {
            this.Hide();
            ChangeUserData frm = new ChangeUserData();
            frm.Show();
        }

        private void MakeOrder_Click(object sender, EventArgs e)
        {
            if (labelName.Text == "Имя: ")
            {
                MessageBox.Show("Заполните информацию о себе! (Кнопка 'Изменить данные')", "Ошибка");
                return;
            }
            else
            {
                this.Hide();
                MakeOrder1 frm = new MakeOrder1();
                frm.Show();
            }
        }
    }
}
