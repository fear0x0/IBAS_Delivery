﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab_SYBD
{
    public partial class AdminPanel : Form
    {
        public AdminPanel()
        {
            InitializeComponent();
        }

        private void AdminPanel_Load(object sender, EventArgs e)
        {
            

            if (AuthorizationForm.currentLogin != "admin")
            { buttonGiveRights.Hide(); buttonDeleteRights.Hide(); LoginField.Hide(); }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            db.openConnection();
            MySqlCommand cmd = new MySqlCommand("CALL `cmndUsers`;", db.getConnection());
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            BindingSource bs = new BindingSource(ds, ds.Tables[0].TableName);
            dataGridView1.DataSource = bs;
            db.closeConnection();
        }

        public Boolean isUserExists()
        {
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand commandCheckRepeats = new MySqlCommand("CALL `cmndCheck`(@ul)", db.getConnection());
            commandCheckRepeats.Parameters.Add("@uL", MySqlDbType.VarChar).Value = LoginField.Text;

            adapter.SelectCommand = commandCheckRepeats;
            adapter.Fill(table);

            if (table.Rows.Count > 0)
            {
                return true;
            }
            else return false;
        }

        private void buttonListAdmins_Click(object sender, EventArgs e)
        {
            DB db = new DB();

            MySqlCommand cmd = new MySqlCommand("CALL `cmndAdmins`;", db.getConnection());

            db.openConnection();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            BindingSource bs = new BindingSource(ds, ds.Tables[0].TableName);
            dataGridView1.DataSource = bs;
            db.closeConnection();
        }

        private void AdminPanel_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void buttonGiveRights_Click(object sender, EventArgs e)
        {
            String loginUser =  LoginField.Text;
            List<string> admins = new List<string>();

            DB db = new DB();
            
            MySqlCommand commandAdmins = new MySqlCommand("CALL `cmndAdmins`;", db.getConnection());
            db.openConnection();

            MySqlDataReader rdr = commandAdmins.ExecuteReader();
            while (rdr.Read())
            {
                admins.Add(rdr["login"].ToString());

            }
            rdr.Close();
            db.closeConnection();

            MySqlCommand commandAddAdmin = new MySqlCommand("CALL `cmndAddAdmin`(@uL)", db.getConnection());

            commandAddAdmin.Parameters.Add("@uL", MySqlDbType.VarChar).Value = loginUser ;
            
            if (isUserExists() && !admins.Contains(loginUser))
            {
                db.openConnection();

                if (commandAddAdmin.ExecuteNonQuery() == 1)
                    MessageBox.Show("Пользователь добавлен в список администраторов!");
                else { MessageBox.Show("Ошибка"); return; }

                db.closeConnection();
            }

            else if (!isUserExists()) { MessageBox.Show("Пользователя не существует!"); return; }

            else if (admins.Contains (loginUser)) 
            { MessageBox.Show("Пользователь уже находится в списке администраторов!"); return; }

            
        }

        private void buttonDeleteRights_Click(object sender, EventArgs e)
        {
            String loginUser = LoginField.Text;
            List<string> admins = new List<string>();

            DB db = new DB();

            MySqlCommand commandAdmins = new MySqlCommand("CALL `cmndAdmins`;", db.getConnection());
            db.openConnection();

            MySqlDataReader rdr = commandAdmins.ExecuteReader();
            while (rdr.Read())
            {
                admins.Add(rdr["login"].ToString());

            }
            rdr.Close();
            db.closeConnection();

            MySqlCommand commandDeleteAdmin = new MySqlCommand("CALL `cmndDeleteAdmin`(@uL)", db.getConnection());

            commandDeleteAdmin.Parameters.Add("@uL", MySqlDbType.VarChar).Value = loginUser;

            if (isUserExists() && admins.Contains(loginUser))
            {
                db.openConnection();

                if (commandDeleteAdmin.ExecuteNonQuery() == 1)
                    MessageBox.Show("Пользователь удалён из списка администраторов!");
                else { MessageBox.Show("Ошибка"); return; }

                db.closeConnection();
            }

            else if (!isUserExists()) { MessageBox.Show("Пользователя не существует!"); return; }

            else if (!admins.Contains(loginUser))
            { MessageBox.Show("Пользователя нет в списке администраторов!"); return; }
        }

        private void buttonUsersInfo_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            db.openConnection();
            MySqlCommand cmd = new MySqlCommand("CALL `cmndUsersInfo`;", db.getConnection());
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            BindingSource bs = new BindingSource(ds, ds.Tables[0].TableName);
            dataGridView1.DataSource = bs;
            db.closeConnection();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AuthorizationForm frm = new AuthorizationForm();
            frm.Show();
        }

        private void buttonGetOrders_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            db.openConnection();
            MySqlCommand cmd = new MySqlCommand("CALL `cmndCustomersOrders`;", db.getConnection());
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            BindingSource bs = new BindingSource(ds, ds.Tables[0].TableName);
            dataGridView1.DataSource = bs;
            db.closeConnection();
        }

        

        private void AddProduct_Click(object sender, EventArgs e)
        {
            DB db = new DB();

            MySqlCommand commandAdd = new MySqlCommand("CALL `cmndAddProduct`(@uL, @uP)", db.getConnection());

            commandAdd.Parameters.Add("@uL", MySqlDbType.VarChar).Value = menameField.Text;
            commandAdd.Parameters.Add("@uP", MySqlDbType.Float).Value = float.Parse(priceField.Text);

            db.openConnection();


            if (commandAdd.ExecuteNonQuery() == 1)
                MessageBox.Show("Продукт добавлен!");
            else MessageBox.Show("Аккаунт не был создан");

            db.closeConnection();
        }

        private void DeleteProduct_Click(object sender, EventArgs e)
        {
            DB db = new DB();

            MySqlCommand commandDel = new MySqlCommand("CALL `cmndDelProduct`(@uL)", db.getConnection());

            commandDel.Parameters.Add("@uL", MySqlDbType.VarChar).Value = comboBox1.Text;

            db.openConnection();


            if (commandDel.ExecuteNonQuery() == 1)
                MessageBox.Show("Продукт удалён!");
            else MessageBox.Show("Аккаунт не был создан");

            db.closeConnection();
        }

        private void comboBox1_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();

            DB db = new DB();

            MySqlCommand commandLastOrder = new MySqlCommand("CALL `cmndGetProducts`;", db.getConnection());

            db.openConnection();

            MySqlDataReader rdr = commandLastOrder.ExecuteReader();
            while (rdr.Read())
            {
                comboBox1.Items.Add(rdr["menu_name"]);
            }
            rdr.Close();


            db.closeConnection();
        }
    }
}
