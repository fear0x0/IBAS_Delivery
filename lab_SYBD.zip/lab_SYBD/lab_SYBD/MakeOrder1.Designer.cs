﻿namespace lab_SYBD
{
    partial class MakeOrder1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label22 = new System.Windows.Forms.Label();
            this.AcceptOrder = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.orderItems = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.Location = new System.Drawing.Point(66, 7);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(51, 29);
            this.label22.TabIndex = 86;
            this.label22.Text = "<---";
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // AcceptOrder
            // 
            this.AcceptOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AcceptOrder.Location = new System.Drawing.Point(246, 404);
            this.AcceptOrder.Name = "AcceptOrder";
            this.AcceptOrder.Size = new System.Drawing.Size(282, 65);
            this.AcceptOrder.TabIndex = 85;
            this.AcceptOrder.Text = "Подтвердить";
            this.AcceptOrder.UseVisualStyleBackColor = true;
            this.AcceptOrder.Click += new System.EventHandler(this.AcceptOrder_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.Location = new System.Drawing.Point(339, 20);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(85, 29);
            this.label21.TabIndex = 84;
            this.label21.Text = "Заказ";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(128, 88);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 24);
            this.comboBox1.TabIndex = 87;
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(128, 158);
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(100, 22);
            this.maskedTextBox1.TabIndex = 88;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(128, 136);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 16);
            this.label1.TabIndex = 89;
            this.label1.Text = "Количество";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(318, 89);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(210, 23);
            this.button1.TabIndex = 90;
            this.button1.Text = "Добавить в заказ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(318, 136);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(210, 23);
            this.button2.TabIndex = 92;
            this.button2.Text = "Убрать из заказа";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // orderItems
            // 
            this.orderItems.FormattingEnabled = true;
            this.orderItems.ItemHeight = 16;
            this.orderItems.Location = new System.Drawing.Point(318, 195);
            this.orderItems.Name = "orderItems";
            this.orderItems.Size = new System.Drawing.Size(210, 84);
            this.orderItems.TabIndex = 91;
            // 
            // MakeOrder1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 504);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.orderItems);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.maskedTextBox1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.AcceptOrder);
            this.Controls.Add(this.label21);
            this.Name = "MakeOrder1";
            this.Text = "MakeOrder1";
            this.Load += new System.EventHandler(this.MakeOrder1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button AcceptOrder;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ListBox orderItems;
    }
}