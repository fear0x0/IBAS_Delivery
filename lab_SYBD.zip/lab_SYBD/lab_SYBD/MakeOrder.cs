﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab_SYBD
{
    public partial class MakeOrder : Form
    {
        public MakeOrder()
        {
            InitializeComponent();
        }

        public Boolean saved;        

        private void label22_Click(object sender, EventArgs e)
        {
            if (saved)
            {
                this.Hide();
                LoggedUserForm frm = new LoggedUserForm();
                frm.Show();
            }
            else 
            {
                DialogResult result = MessageBox.Show
                    ("У вас есть несохранённый заказ. Вы действительно хотите выйти в главное меню?", "Ошибка"
                    ,MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    this.Hide();
                    LoggedUserForm frm = new LoggedUserForm();
                    frm.Show();
                }
                if (result == DialogResult.No)
                {
                    this.TopMost = true;
                }
            }
        }

        public string curAmount, curProduct;

        public Boolean semgaChecked()
        {

            if (SemgaCount.MaskCompleted && checkBoxSemga.Checked)
            { curAmount = SemgaCount.Text; SemgaCount.Text = ""; curProduct = "1"; checkBoxSemga.Checked = false; return true; }
            else return false;
        }

        public Boolean muraChecked() 
        {
            if (MuraCount.MaskCompleted && checkBoxMura.Checked)
            { curAmount = MuraCount.Text; MuraCount.Text = ""; curProduct = "2"; checkBoxMura.Checked = false; return true; }
            else return false; 
        }

        public Boolean molokoChecked() {
            if (MolokoCount.MaskCompleted && checkBoxMoloko.Checked)
            { curAmount = MolokoCount.Text; MolokoCount.Text = ""; curProduct = "3"; checkBoxMoloko.Checked = false; return true; }
            else return false;
        }

        public Boolean tvorogChecked() 
        {
            if (TvorogCount.MaskCompleted && checkBoxTvorog.Checked)
            { curAmount = TvorogCount.Text; TvorogCount.Text = ""; curProduct = "4"; checkBoxTvorog.Checked = false; return true; }
            else return false;

        }
        public Boolean smetanaChecked()
        {
            if (SmetanaCount.MaskCompleted && checkBoxSmetana.Checked)
            { curAmount = SmetanaCount.Text; SmetanaCount.Text = ""; curProduct = "5"; checkBoxSmetana.Checked = false; return true; }
            else return false;
        }
        public Boolean sokChecked() 
        {
            if (SokCount.MaskCompleted && checkBoxSok.Checked)
            { curAmount = SokCount.Text; SokCount.Text = ""; curProduct = "7"; checkBoxSok.Checked = false; return true; }
            else return false;
        }
        public Boolean tvorsirChecked()
        {
            if (TvorSirCount.MaskCompleted && checkBoxTvorSir.Checked)
            { curAmount = TvorSirCount.Text; TvorSirCount.Text = ""; curProduct = "8"; checkBoxTvorSir.Checked = false; return true; }
            else return false;
        }
        public Boolean pirogChecked() 
        {
            if (PirogCount.MaskCompleted && checkBoxPirog.Checked)
            { curAmount = PirogCount.Text; PirogCount.Text = ""; curProduct = "9"; checkBoxPirog.Checked = false; return true; }
                else return false;
        }
        public Boolean slivmasloChecked() 
        {
            if (SlivMasloCount.MaskCompleted && checkBoxMaslo.Checked)
            { curAmount = SlivMasloCount.Text; SlivMasloCount.Text = ""; curProduct = "6"; checkBoxMaslo.Checked = false; return true; }
            else return false;
        }
        public Boolean ikraChecked() 
        {
            if (IkraCount.MaskCompleted && checkBoxIkra.Checked)
            { curAmount = IkraCount.Text; IkraCount.Text = ""; curProduct = "10"; checkBoxIkra.Checked = false; return true; }
            else return false;
        }
        

        private void MakeOrder_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
            
        }

        public static string orderId = string.Empty;



        private void AcceptOrder_Click(object sender, EventArgs e)
        {


            saved = true;



            DB db = new DB();

            MySqlCommand commandAddOrder = new MySqlCommand("CALL `cmndAddOrder`(@uL)", db.getConnection());

            commandAddOrder.Parameters.Add("@uL", MySqlDbType.VarChar).Value = AuthorizationForm.currentLogin;

            MySqlCommand commandOrderId = new MySqlCommand("CALL `cmndOrderId`", db.getConnection());

            


            db.openConnection();

            if (commandAddOrder.ExecuteNonQuery() == 1)
                MessageBox.Show("Заказ принят в обработку!");
            else { MessageBox.Show("Ошибка"); return; }

            db.closeConnection();

            db.openConnection();

            orderId = commandOrderId.ExecuteScalar().ToString();

            db.closeConnection();

            MySqlCommand commandOrderProducts = new MySqlCommand("CALL `cmndOrderProducts`(@orid, @prodid, @amnt)", db.getConnection());

            db.openConnection();


            //while (semgaChecked() || muraChecked() || molokoChecked() || tvorogChecked() || smetanaChecked() || slivmasloChecked() || sokChecked() || tvorsirChecked() || pirogChecked() || ikraChecked())
            //{
            //    commandOrderProducts.Parameters.Add("@orid", MySqlDbType.Int64).Value = orderId;
            //    commandOrderProducts.Parameters.Add("@prodid", MySqlDbType.Int64).Value = Int64.Parse(curProduct);
            //    commandOrderProducts.Parameters.Add("@amnt", MySqlDbType.Int64).Value = Int64.Parse(curAmount);

            //    if (commandOrderProducts.ExecuteNonQuery() != 1) { MessageBox.Show("Ошибка"); return; }
            //}
            //MySqlParameter orid = new MySqlParameter("@orid", MySqlDbType.Int64);
            //MySqlParameter prodid = new MySqlParameter("@prodid", MySqlDbType.Int64);
            //MySqlParameter amnt = new MySqlParameter("@amnt", MySqlDbType.Int64);

            //orid.Value = 1;
            //prodid.Value = 1;
            //amnt.Value = 1;

            if (semgaChecked())
            {
                //orid.Value = orderId;
                //prodid.Value = Int64.Parse(curProduct);
                //amnt.Value = Int64.Parse(curAmount);
                commandOrderProducts.Parameters.Add("@orid", MySqlDbType.Int64).Value = orderId;
                commandOrderProducts.Parameters.Add("@prodid", MySqlDbType.Int64).Value = Int64.Parse(curProduct);
                commandOrderProducts.Parameters.Add("@amnt", MySqlDbType.Int64).Value = Int64.Parse(curAmount);
                if (commandOrderProducts.ExecuteNonQuery() != 1) { MessageBox.Show("Ошибка"); return; }
            }

            if (muraChecked())
            {
                commandOrderProducts.Parameters.Clear();
                //orid.Value = orderId;
                //prodid.Value = Int64.Parse(curProduct);
                //amnt.Value = Int64.Parse(curAmount);
                commandOrderProducts.Parameters.Add("@orid", MySqlDbType.Int64).Value = orderId;
                commandOrderProducts.Parameters.Add("@prodid", MySqlDbType.Int64).Value = Int64.Parse(curProduct);
                commandOrderProducts.Parameters.Add("@amnt", MySqlDbType.Int64).Value = Int64.Parse(curAmount);

                if (commandOrderProducts.ExecuteNonQuery() != 1) { MessageBox.Show("Ошибка"); return; }
            }

            if (molokoChecked())
            {
                commandOrderProducts.Parameters.Clear();
                //orid.Value = orderId;
                //prodid.Value = Int64.Parse(curProduct);
                //amnt.Value = Int64.Parse(curAmount);
                commandOrderProducts.Parameters.Add("@orid", MySqlDbType.Int64).Value = orderId;
                commandOrderProducts.Parameters.Add("@prodid", MySqlDbType.Int64).Value = Int64.Parse(curProduct);
                commandOrderProducts.Parameters.Add("@amnt", MySqlDbType.Int64).Value = Int64.Parse(curAmount);

                if (commandOrderProducts.ExecuteNonQuery() != 1) { MessageBox.Show("Ошибка"); return; }
            }

            if (tvorogChecked())
            {
                commandOrderProducts.Parameters.Clear();
                //orid.Value = orderId;
                //prodid.Value = Int64.Parse(curProduct);
                //amnt.Value = Int64.Parse(curAmount);
                commandOrderProducts.Parameters.Add("@orid", MySqlDbType.Int64).Value = orderId;
                commandOrderProducts.Parameters.Add("@prodid", MySqlDbType.Int64).Value = Int64.Parse(curProduct);
                commandOrderProducts.Parameters.Add("@amnt", MySqlDbType.Int64).Value = Int64.Parse(curAmount);

                if (commandOrderProducts.ExecuteNonQuery() != 1) { MessageBox.Show("Ошибка"); return; }
            }

            if (smetanaChecked())
            {
                commandOrderProducts.Parameters.Clear();
                //orid.Value = orderId;
                //prodid.Value = Int64.Parse(curProduct);
                //amnt.Value = Int64.Parse(curAmount);
                commandOrderProducts.Parameters.Add("@orid", MySqlDbType.Int64).Value = orderId;
                commandOrderProducts.Parameters.Add("@prodid", MySqlDbType.Int64).Value = Int64.Parse(curProduct);
                commandOrderProducts.Parameters.Add("@amnt", MySqlDbType.Int64).Value = Int64.Parse(curAmount);

                if (commandOrderProducts.ExecuteNonQuery() != 1) { MessageBox.Show("Ошибка"); return; }
            }

            if (slivmasloChecked())
            {
                commandOrderProducts.Parameters.Clear();
                //orid.Value = orderId;
                //prodid.Value = Int64.Parse(curProduct);
                //amnt.Value = Int64.Parse(curAmount);
                commandOrderProducts.Parameters.Add("@orid", MySqlDbType.Int64).Value = orderId;
                commandOrderProducts.Parameters.Add("@prodid", MySqlDbType.Int64).Value = Int64.Parse(curProduct);
                commandOrderProducts.Parameters.Add("@amnt", MySqlDbType.Int64).Value = Int64.Parse(curAmount);

                if (commandOrderProducts.ExecuteNonQuery() != 1) { MessageBox.Show("Ошибка"); return; }
            }

            if (sokChecked())
            {
                commandOrderProducts.Parameters.Clear();
                //orid.Value = orderId;
                //prodid.Value = Int64.Parse(curProduct);
                //amnt.Value = Int64.Parse(curAmount);
                commandOrderProducts.Parameters.Add("@orid", MySqlDbType.Int64).Value = orderId;
                commandOrderProducts.Parameters.Add("@prodid", MySqlDbType.Int64).Value = Int64.Parse(curProduct);
                commandOrderProducts.Parameters.Add("@amnt", MySqlDbType.Int64).Value = Int64.Parse(curAmount);

                if (commandOrderProducts.ExecuteNonQuery() != 1) { MessageBox.Show("Ошибка"); return; }
            }

            if (tvorsirChecked())
            {
                commandOrderProducts.Parameters.Clear();
                //orid.Value = orderId;
                //prodid.Value = Int64.Parse(curProduct);
                //amnt.Value = Int64.Parse(curAmount);
                commandOrderProducts.Parameters.Add("@orid", MySqlDbType.Int64).Value = orderId;
                commandOrderProducts.Parameters.Add("@prodid", MySqlDbType.Int64).Value = Int64.Parse(curProduct);
                commandOrderProducts.Parameters.Add("@amnt", MySqlDbType.Int64).Value = Int64.Parse(curAmount);

                if (commandOrderProducts.ExecuteNonQuery() != 1) { MessageBox.Show("Ошибка"); return; }
            }

            if (pirogChecked())
            {
                commandOrderProducts.Parameters.Clear();
                //orid.Value = orderId;
                //prodid.Value = Int64.Parse(curProduct);
                //amnt.Value = Int64.Parse(curAmount);
                commandOrderProducts.Parameters.Add("@orid", MySqlDbType.Int64).Value = orderId;
                commandOrderProducts.Parameters.Add("@prodid", MySqlDbType.Int64).Value = Int64.Parse(curProduct);
                commandOrderProducts.Parameters.Add("@amnt", MySqlDbType.Int64).Value = Int64.Parse(curAmount);

                if (commandOrderProducts.ExecuteNonQuery() != 1) { MessageBox.Show("Ошибка"); return; }
            }

            if (ikraChecked())
            {
                commandOrderProducts.Parameters.Clear();
                //orid.Value = orderId;
                //prodid.Value = Int64.Parse(curProduct);
                //amnt.Value = Int64.Parse(curAmount);
                commandOrderProducts.Parameters.Add("@orid", MySqlDbType.Int64).Value = orderId;
                commandOrderProducts.Parameters.Add("@prodid", MySqlDbType.Int64).Value = Int64.Parse(curProduct);
                commandOrderProducts.Parameters.Add("@amnt", MySqlDbType.Int64).Value = Int64.Parse(curAmount);

                if (commandOrderProducts.ExecuteNonQuery() != 1) { MessageBox.Show("Ошибка"); return; }
            }
            db.closeConnection();


            
            
        }

        private void checkBoxSemga_CheckedChanged(object sender, EventArgs e)
        {
            if (!SemgaCount.MaskCompleted && checkBoxSemga.Checked)
            {
                MessageBox.Show("Сначала напишите количество!");
                return;
            }

            if (checkBoxSemga.Checked) saved = false;
        }

        private void checkBoxMura_CheckedChanged(object sender, EventArgs e)
        {
            if (!MuraCount.MaskCompleted && checkBoxMura.Checked)
            {
                checkBoxMura.Checked = false;
                MessageBox.Show("Сначала напишите количество!");
                return;
            }
            if (checkBoxMura.Checked) saved = false;
        }

        private void checkBoxMoloko_CheckedChanged(object sender, EventArgs e)
        {
            if (!MolokoCount.MaskCompleted && checkBoxMoloko.Checked)
            {
                checkBoxMoloko.Checked = false;
                MessageBox.Show("Сначала напишите количество!");
                return;
            }
            if (checkBoxMoloko.Checked) saved = false;
        }

        private void checkBoxTvorog_CheckedChanged(object sender, EventArgs e)
        {
            if (!TvorogCount.MaskCompleted && checkBoxTvorog.Checked)
            {
                checkBoxTvorog.Checked = false;
                MessageBox.Show("Сначала напишите количество!");
                return;
            }
            if (checkBoxTvorog.Checked)
                saved = false;
        }

        private void checkBoxSmetana_CheckedChanged(object sender, EventArgs e)
        {
            if (!SmetanaCount.MaskCompleted && checkBoxSmetana.Checked)
            {
                checkBoxSmetana.Checked = false;
                MessageBox.Show("Сначала напишите количество!");
                return;
            }
            if (checkBoxSmetana.Checked)
                saved = false;
        }

        private void checkBoxMaslo_CheckedChanged(object sender, EventArgs e)
        {
            if (!SlivMasloCount.MaskCompleted && checkBoxMaslo.Checked)
            {
                checkBoxMaslo.Checked = false;
                MessageBox.Show("Сначала напишите количество!");
                return;
            }
            if (checkBoxMaslo.Checked)
                saved = false;
        }

        private void checkBoxSok_CheckedChanged(object sender, EventArgs e)
        {
            if (!SokCount.MaskCompleted && checkBoxSok.Checked)
            {
                checkBoxSok.Checked = false;
                MessageBox.Show("Сначала напишите количество!");
                return;
            }
            if (checkBoxSok.Checked)
                saved = false;
        }

        private void checkBoxTvorSir_CheckedChanged(object sender, EventArgs e)
        {
            if (!TvorSirCount.MaskCompleted && checkBoxTvorSir.Checked)
            {
                checkBoxTvorSir.Checked = false;
                MessageBox.Show("Сначала напишите количество!");
                return;
            }
            if (checkBoxTvorSir.Checked)
                saved = false;
        }

        private void checkBoxPirog_CheckedChanged(object sender, EventArgs e)
        {
            if (!PirogCount.MaskCompleted && checkBoxPirog.Checked)
            {
                checkBoxPirog.Checked = false;
                MessageBox.Show("Сначала напишите количество!");
                return;
            }
            if (checkBoxPirog.Checked)
                saved = false;
        }

        private void checkBoxIkra_CheckedChanged(object sender, EventArgs e)
        {
            if (!IkraCount.MaskCompleted && checkBoxIkra.Checked)
            {
                checkBoxIkra.Checked = false;
                MessageBox.Show("Сначала напишите количество!");
                return;
            }
            if (checkBoxIkra.Checked)
                saved = false;
        }
    }
}
