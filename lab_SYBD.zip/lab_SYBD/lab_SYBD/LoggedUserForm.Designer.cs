﻿namespace lab_SYBD
{
    partial class LoggedUserForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoggedUserForm));
            this.label1 = new System.Windows.Forms.Label();
            this.WelcomeLable = new System.Windows.Forms.Label();
            this.ExitFromAcc = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.labelApartment = new System.Windows.Forms.Label();
            this.labelHouse = new System.Windows.Forms.Label();
            this.labelStreet = new System.Windows.Forms.Label();
            this.labelDistrict = new System.Windows.Forms.Label();
            this.labelPhone = new System.Windows.Forms.Label();
            this.labelSurname = new System.Windows.Forms.Label();
            this.ChangeData = new System.Windows.Forms.Button();
            this.LastOrder = new System.Windows.Forms.Label();
            this.MakeOrder = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(366, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(217, 32);
            this.label1.TabIndex = 7;
            this.label1.Text = "Главное меню";
            // 
            // WelcomeLable
            // 
            this.WelcomeLable.AutoSize = true;
            this.WelcomeLable.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.WelcomeLable.Location = new System.Drawing.Point(12, 81);
            this.WelcomeLable.Name = "WelcomeLable";
            this.WelcomeLable.Size = new System.Drawing.Size(192, 25);
            this.WelcomeLable.TabIndex = 8;
            this.WelcomeLable.Text = "Приветствуем Вас,";
            // 
            // ExitFromAcc
            // 
            this.ExitFromAcc.AutoSize = true;
            this.ExitFromAcc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ExitFromAcc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ExitFromAcc.Location = new System.Drawing.Point(12, 9);
            this.ExitFromAcc.Name = "ExitFromAcc";
            this.ExitFromAcc.Size = new System.Drawing.Size(140, 18);
            this.ExitFromAcc.TabIndex = 9;
            this.ExitFromAcc.Text = "Выход из аккаунта";
            this.ExitFromAcc.Click += new System.EventHandler(this.ExitFromAcc_Click);
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(10, 123);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(86, 25);
            this.labelName.TabIndex = 10;
            this.labelName.Text = "Данные";
            // 
            // labelApartment
            // 
            this.labelApartment.AutoSize = true;
            this.labelApartment.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelApartment.Location = new System.Drawing.Point(10, 357);
            this.labelApartment.Name = "labelApartment";
            this.labelApartment.Size = new System.Drawing.Size(86, 25);
            this.labelApartment.TabIndex = 11;
            this.labelApartment.Text = "Данные";
            // 
            // labelHouse
            // 
            this.labelHouse.AutoSize = true;
            this.labelHouse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelHouse.Location = new System.Drawing.Point(10, 316);
            this.labelHouse.Name = "labelHouse";
            this.labelHouse.Size = new System.Drawing.Size(86, 25);
            this.labelHouse.TabIndex = 12;
            this.labelHouse.Text = "Данные";
            // 
            // labelStreet
            // 
            this.labelStreet.AutoSize = true;
            this.labelStreet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelStreet.Location = new System.Drawing.Point(10, 275);
            this.labelStreet.Name = "labelStreet";
            this.labelStreet.Size = new System.Drawing.Size(86, 25);
            this.labelStreet.TabIndex = 13;
            this.labelStreet.Text = "Данные";
            // 
            // labelDistrict
            // 
            this.labelDistrict.AutoSize = true;
            this.labelDistrict.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelDistrict.Location = new System.Drawing.Point(10, 237);
            this.labelDistrict.Name = "labelDistrict";
            this.labelDistrict.Size = new System.Drawing.Size(86, 25);
            this.labelDistrict.TabIndex = 14;
            this.labelDistrict.Text = "Данные";
            // 
            // labelPhone
            // 
            this.labelPhone.AutoSize = true;
            this.labelPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelPhone.Location = new System.Drawing.Point(10, 198);
            this.labelPhone.Name = "labelPhone";
            this.labelPhone.Size = new System.Drawing.Size(86, 25);
            this.labelPhone.TabIndex = 15;
            this.labelPhone.Text = "Данные";
            // 
            // labelSurname
            // 
            this.labelSurname.AutoSize = true;
            this.labelSurname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelSurname.Location = new System.Drawing.Point(10, 158);
            this.labelSurname.Name = "labelSurname";
            this.labelSurname.Size = new System.Drawing.Size(86, 25);
            this.labelSurname.TabIndex = 16;
            this.labelSurname.Text = "Данные";
            // 
            // ChangeData
            // 
            this.ChangeData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ChangeData.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ChangeData.Location = new System.Drawing.Point(64, 402);
            this.ChangeData.Name = "ChangeData";
            this.ChangeData.Size = new System.Drawing.Size(228, 36);
            this.ChangeData.TabIndex = 17;
            this.ChangeData.Text = "Изменить данные";
            this.ChangeData.UseVisualStyleBackColor = true;
            this.ChangeData.Click += new System.EventHandler(this.ChangeData_Click);
            // 
            // LastOrder
            // 
            this.LastOrder.AutoSize = true;
            this.LastOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LastOrder.Location = new System.Drawing.Point(513, 81);
            this.LastOrder.Name = "LastOrder";
            this.LastOrder.Size = new System.Drawing.Size(86, 25);
            this.LastOrder.TabIndex = 18;
            this.LastOrder.Text = "Данные";
            // 
            // MakeOrder
            // 
            this.MakeOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MakeOrder.Location = new System.Drawing.Point(585, 357);
            this.MakeOrder.Name = "MakeOrder";
            this.MakeOrder.Size = new System.Drawing.Size(251, 78);
            this.MakeOrder.TabIndex = 19;
            this.MakeOrder.Text = "Сделать заказ";
            this.MakeOrder.UseVisualStyleBackColor = true;
            this.MakeOrder.Click += new System.EventHandler(this.MakeOrder_Click);
            // 
            // LoggedUserForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(932, 450);
            this.Controls.Add(this.MakeOrder);
            this.Controls.Add(this.LastOrder);
            this.Controls.Add(this.ChangeData);
            this.Controls.Add(this.labelSurname);
            this.Controls.Add(this.labelPhone);
            this.Controls.Add(this.labelDistrict);
            this.Controls.Add(this.labelStreet);
            this.Controls.Add(this.labelHouse);
            this.Controls.Add(this.labelApartment);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.ExitFromAcc);
            this.Controls.Add(this.WelcomeLable);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "LoggedUserForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Go.Доставка";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.LoggedUserForm_FormClosed);
            this.Load += new System.EventHandler(this.LoggedUserForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label WelcomeLable;
        private System.Windows.Forms.Label ExitFromAcc;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelApartment;
        private System.Windows.Forms.Label labelHouse;
        private System.Windows.Forms.Label labelStreet;
        private System.Windows.Forms.Label labelDistrict;
        private System.Windows.Forms.Label labelPhone;
        private System.Windows.Forms.Label labelSurname;
        private System.Windows.Forms.Button ChangeData;
        private System.Windows.Forms.Label LastOrder;
        private System.Windows.Forms.Button MakeOrder;
    }
}