﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab_SYBD
{
    public partial class MakeOrder1 : Form
    {
        public MakeOrder1()
        {
            InitializeComponent();
        }

        private void MakeOrder1_Load(object sender, EventArgs e)
        {
            DB db = new DB();

            MySqlCommand commandLastOrder = new MySqlCommand("CALL `cmndGetProducts`;", db.getConnection());

            db.openConnection();

            MySqlDataReader rdr = commandLastOrder.ExecuteReader();
            while (rdr.Read())
            {
                comboBox1.Items.Add(rdr["menu_name"]);
            }
            rdr.Close();


            db.closeConnection();
        }
        public static List<string> order = new List<string>();
        private void label22_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoggedUserForm frm = new LoggedUserForm();
            frm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            orderItems.Items.Add(comboBox1.Text);
            order.Add(comboBox1.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            orderItems.Items.Remove(orderItems.SelectedItem);
            order.Remove(comboBox1.Text);
        }
        public static string orderId = string.Empty;
        public static string curProduct = string.Empty;
        public static string curAmount = string.Empty;
        private void AcceptOrder_Click(object sender, EventArgs e)
        {
            DB db = new DB();

            MySqlCommand commandAddOrder = new MySqlCommand("CALL `cmndAddOrder`(@uL)", db.getConnection());

            commandAddOrder.Parameters.Add("@uL", MySqlDbType.VarChar).Value = AuthorizationForm.currentLogin;

            MySqlCommand commandOrderId = new MySqlCommand("CALL `cmndOrderId`", db.getConnection());
            
            MySqlCommand commandGetProducts = new MySqlCommand("CALL `cmndGetProducts`;", db.getConnection());
            
            List<string> products = new List<string>();
            List<string> order = new List<string>();
            
            foreach (string items in orderItems.Items)
                order.Add(items);


            db.openConnection();

            MySqlDataReader rdr = commandGetProducts.ExecuteReader();
            while (rdr.Read())
            {
                products.Add(rdr["menu_name"].ToString());
                
            }
            rdr.Close();
            db.closeConnection();

            
            db.openConnection();

            if (commandAddOrder.ExecuteNonQuery() == 1)
                MessageBox.Show("Заказ принят в обработку!");
            else { MessageBox.Show("Ошибка"); return; }

            db.closeConnection();

            db.openConnection();

            orderId = commandOrderId.ExecuteScalar().ToString();

            db.closeConnection();

            MySqlCommand commandOrderProducts = new MySqlCommand("CALL `cmndOrderProducts`(@orid, @prodid, @amnt)", db.getConnection());

            db.openConnection();
            while (orderItems.Items.Count > 0)
            {
                commandOrderProducts.Parameters.Clear();
                //orid.Value = orderId;
                //prodid.Value = Int64.Parse(curProduct);
                //amnt.Value = Int64.Parse(curAmount);
                commandOrderProducts.Parameters.Add("@orid", MySqlDbType.Int64).Value = orderId;
                bool a = true;
                while (a)
                {
                    if (order.Count > 0 && order.Contains("Сёмга")) { curProduct = "1"; order.Remove("Сёмга"); a = false; }
                    else if (order.Count > 0 && order.Contains("Муравейник")) { curProduct = "2"; order.Remove("Муравейник"); a = false; }
                    else if (order.Count > 0 && order.Contains("Молоко")) { curProduct = "3"; order.Remove("Молоко"); a = false; }
                    else if (order.Count > 0 && order.Contains("Творог")) { curProduct = "4"; order.Remove("Творог"); a = false; }
                    else if (order.Count > 0 && order.Contains("Сметана")) { curProduct = "5"; order.Remove("Сметана"); a = false; }
                    else if (order.Count > 0 && order.Contains("Сливочное масло")) { curProduct = "6"; order.Remove("Сливочное масло"); a = false; }
                    else if (order.Count > 0 && order.Contains("Сок")) { curProduct = "7"; order.Remove("Сок"); a = false; }
                    else if (order.Count > 0 && order.Contains("Творожный сыр")) { curProduct = "8"; order.Remove("Творожный сыр"); a = false; }
                    else if (order.Count > 0 && order.Contains("Пирог")) { curProduct = "9"; order.Remove("Пирог"); a = false; }
                    else if (order.Count > 0 && order.Contains("Икра красная")) { curProduct = "10"; order.Remove("Икра красная"); a = false; }
                    orderItems.Items.Remove(comboBox1.Text);
                }
                commandOrderProducts.Parameters.Add("@prodid", MySqlDbType.Int64).Value = Int64.Parse(curProduct);
                commandOrderProducts.Parameters.Add("@amnt", MySqlDbType.Int64).Value = 2;
                if (commandOrderProducts.ExecuteNonQuery() != 1) { MessageBox.Show("Ошибка"); return; }

            }
            db.closeConnection();
        }
    }
}
