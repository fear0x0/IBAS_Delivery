﻿using MySqlConnector; 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab_SYBD
{
    public partial class AuthorizationForm : Form
    {
        public AuthorizationForm()
        {
            InitializeComponent();
        }

        public static string currentLogin;

        //private void CloseButton_Click(object sender, EventArgs e)
        //{
        //    this.Close();
        //}

        

        
        private void ButtonLogin_Click(object sender, EventArgs e)
        {
            String loginUser = LoginField.Text;
            String passUser = PasswordField.Text;
            
            List<string> admins = new List<string>();
            
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand commandAuth  = new MySqlCommand("CALL `cmndAuth`(@uL, @uP);", db.getConnection());
            commandAuth.Parameters.Add("@uL", MySqlDbType.VarChar).Value = loginUser;
            commandAuth.Parameters.Add("@uP", MySqlDbType.VarChar).Value = passUser;

            MySqlCommand commandAdmins = new MySqlCommand("CALL `cmndAdmins`;", db.getConnection());

            adapter.SelectCommand = commandAuth;
            adapter.Fill(table);

            db.openConnection();

            MySqlDataReader rdr = commandAdmins.ExecuteReader();
            while (rdr.Read())
            {
                admins.Add(rdr["login"].ToString());
                
            }
            rdr.Close();
            db.closeConnection();



            if (table.Rows.Count > 0 && LoginField.Text == "admin")
            {
                currentLogin = LoginField.Text;
                this.Hide();
                AdminPanel form = new AdminPanel();
                form.Show();
            }

            else if (table.Rows.Count > 0  && admins.Contains(loginUser))
            {
                currentLogin = LoginField.Text;
                //this.Hide();
                //LoggedUserForm form = new LoggedUserForm();
                //form.Show();
                DialogResult result = MessageBox.Show
                    ("У вас есть права администратора. Хотите войти как администратор (Да) или обычный пользователь (Нет)", "Способ входа",
                    MessageBoxButtons.YesNo);

                if (result == DialogResult.Yes)
                {
                    this.Hide();
                    AdminPanel frm = new AdminPanel();
                    frm.Show();
                }
                if (result == DialogResult.No)
                {
                    this.Hide();
                    LoggedUserForm frm = new LoggedUserForm();
                    frm.Show();
                }
            }

            else if (table.Rows.Count > 0 && LoginField.Text != "admin")
            {
                currentLogin = LoginField.Text;
                this.Hide();
                LoggedUserForm form = new LoggedUserForm();
                form.Show();
            }    
            else MessageBox.Show("Пользователя не существует");
            

            
        }

        private void ToRegisterButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            RegisterForm form = new RegisterForm();
            form.Show();
        }

        private void AuthorizationForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
