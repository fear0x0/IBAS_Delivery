﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab_SYBD
{
    public partial class RegisterForm : Form
    {
        public RegisterForm()
        {
            InitializeComponent();
        }

        

        private void HideLabel_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

       

        private void ButtonRegister_Click(object sender, EventArgs e)
        {
            if (isUserExists()) return;

            if (!LoginField.MaskCompleted)
            {
                MessageBox.Show("Логин должен состоять как минимум из трёх символов!", "Ошибка");
                return;
            }

            if (PasswordField.Text.Length < 4)
            {
                MessageBox.Show("Пароль должен состоять минимум из 4 символов!", "Ошибка");
                return;
            }

            DB db = new DB();

            MySqlCommand commandReg = new MySqlCommand("CALL `cmndRegister`(@uL, @uP)", db.getConnection());

            commandReg.Parameters.Add("@uL", MySqlDbType.VarChar).Value = LoginField.Text;
            commandReg.Parameters.Add("@uP", MySqlDbType.VarChar).Value = PasswordField.Text;

            

            if (LoginField.Text == "")
            {
                MessageBox.Show("Заполните поле Логин!");
                return;
            }

            if (PasswordField.Text == "")
            {
                MessageBox.Show("Заполните поле Пароль!");
                return;
            }

            db.openConnection();


            if (commandReg.ExecuteNonQuery() == 1)
                MessageBox.Show("Аккаунт был создан");
            else MessageBox.Show("Аккаунт не был создан");

            db.closeConnection();

        }

        public Boolean isUserExists()
        {
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand commandCheckRepeats = new MySqlCommand("CALL `cmndCheck`(@ul)", db.getConnection());
            commandCheckRepeats.Parameters.Add("@uL", MySqlDbType.VarChar).Value = LoginField.Text;

            adapter.SelectCommand = commandCheckRepeats;
            adapter.Fill(table);

            if (table.Rows.Count > 0)
            {
                MessageBox.Show("Такой логин уже есть!");
                return true;
            }
            else return false;
        }

        private void GoToLoginForm_Click(object sender, EventArgs e)
        {
            this.Hide();
            AuthorizationForm form = new AuthorizationForm();
            form.Show();
        }

        private void RegisterForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
