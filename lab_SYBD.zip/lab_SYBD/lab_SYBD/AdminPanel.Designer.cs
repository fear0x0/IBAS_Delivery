﻿namespace lab_SYBD
{
    partial class AdminPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.buttonListAdmins = new System.Windows.Forms.Button();
            this.LoginField = new System.Windows.Forms.TextBox();
            this.buttonGiveRights = new System.Windows.Forms.Button();
            this.buttonDeleteRights = new System.Windows.Forms.Button();
            this.buttonUsersInfo = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonGetOrders = new System.Windows.Forms.Button();
            this.AddProduct = new System.Windows.Forms.Button();
            this.DeleteProduct = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.menameField = new System.Windows.Forms.MaskedTextBox();
            this.priceField = new System.Windows.Forms.MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(84, 487);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(184, 83);
            this.button1.TabIndex = 0;
            this.button1.Text = "Вывести пользователей";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(84, 62);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1268, 387);
            this.dataGridView1.TabIndex = 1;
            // 
            // buttonListAdmins
            // 
            this.buttonListAdmins.Location = new System.Drawing.Point(300, 487);
            this.buttonListAdmins.Name = "buttonListAdmins";
            this.buttonListAdmins.Size = new System.Drawing.Size(200, 83);
            this.buttonListAdmins.TabIndex = 2;
            this.buttonListAdmins.Text = "Вывести список администраторов";
            this.buttonListAdmins.UseVisualStyleBackColor = true;
            this.buttonListAdmins.Click += new System.EventHandler(this.buttonListAdmins_Click);
            // 
            // LoginField
            // 
            this.LoginField.Location = new System.Drawing.Point(1119, 487);
            this.LoginField.Name = "LoginField";
            this.LoginField.Size = new System.Drawing.Size(233, 22);
            this.LoginField.TabIndex = 3;
            // 
            // buttonGiveRights
            // 
            this.buttonGiveRights.Location = new System.Drawing.Point(1119, 515);
            this.buttonGiveRights.Name = "buttonGiveRights";
            this.buttonGiveRights.Size = new System.Drawing.Size(233, 55);
            this.buttonGiveRights.TabIndex = 4;
            this.buttonGiveRights.Text = "Дать права администратора пользователю";
            this.buttonGiveRights.UseVisualStyleBackColor = true;
            this.buttonGiveRights.Click += new System.EventHandler(this.buttonGiveRights_Click);
            // 
            // buttonDeleteRights
            // 
            this.buttonDeleteRights.Location = new System.Drawing.Point(1119, 576);
            this.buttonDeleteRights.Name = "buttonDeleteRights";
            this.buttonDeleteRights.Size = new System.Drawing.Size(233, 73);
            this.buttonDeleteRights.TabIndex = 5;
            this.buttonDeleteRights.Text = "Отобрать права администратора у пользователя";
            this.buttonDeleteRights.UseVisualStyleBackColor = true;
            this.buttonDeleteRights.Click += new System.EventHandler(this.buttonDeleteRights_Click);
            // 
            // buttonUsersInfo
            // 
            this.buttonUsersInfo.Location = new System.Drawing.Point(84, 588);
            this.buttonUsersInfo.Name = "buttonUsersInfo";
            this.buttonUsersInfo.Size = new System.Drawing.Size(184, 61);
            this.buttonUsersInfo.TabIndex = 6;
            this.buttonUsersInfo.Text = "Информация о пользователях";
            this.buttonUsersInfo.UseVisualStyleBackColor = true;
            this.buttonUsersInfo.Click += new System.EventHandler(this.buttonUsersInfo_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(81, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(211, 20);
            this.label1.TabIndex = 7;
            this.label1.Text = "Выйти из админ панели";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // buttonGetOrders
            // 
            this.buttonGetOrders.Location = new System.Drawing.Point(534, 487);
            this.buttonGetOrders.Name = "buttonGetOrders";
            this.buttonGetOrders.Size = new System.Drawing.Size(211, 83);
            this.buttonGetOrders.TabIndex = 8;
            this.buttonGetOrders.Text = "Вывести список заказов";
            this.buttonGetOrders.UseVisualStyleBackColor = true;
            this.buttonGetOrders.Click += new System.EventHandler(this.buttonGetOrders_Click);
            // 
            // AddProduct
            // 
            this.AddProduct.Location = new System.Drawing.Point(771, 488);
            this.AddProduct.Name = "AddProduct";
            this.AddProduct.Size = new System.Drawing.Size(153, 52);
            this.AddProduct.TabIndex = 9;
            this.AddProduct.Text = "Добавить продукт";
            this.AddProduct.UseVisualStyleBackColor = true;
            this.AddProduct.Click += new System.EventHandler(this.AddProduct_Click);
            // 
            // DeleteProduct
            // 
            this.DeleteProduct.Location = new System.Drawing.Point(771, 559);
            this.DeleteProduct.Name = "DeleteProduct";
            this.DeleteProduct.Size = new System.Drawing.Size(153, 45);
            this.DeleteProduct.TabIndex = 10;
            this.DeleteProduct.Text = "Удалить продукт";
            this.DeleteProduct.UseVisualStyleBackColor = true;
            this.DeleteProduct.Click += new System.EventHandler(this.DeleteProduct_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(943, 559);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 24);
            this.comboBox1.TabIndex = 11;
            this.comboBox1.Click += new System.EventHandler(this.comboBox1_Click);
            // 
            // menameField
            // 
            this.menameField.Location = new System.Drawing.Point(943, 486);
            this.menameField.Mask = "LLLLLLLLLLLLLLLLLL";
            this.menameField.Name = "menameField";
            this.menameField.Size = new System.Drawing.Size(100, 22);
            this.menameField.TabIndex = 12;
            // 
            // priceField
            // 
            this.priceField.Location = new System.Drawing.Point(943, 517);
            this.priceField.Mask = "0000000000000000000000000";
            this.priceField.Name = "priceField";
            this.priceField.Size = new System.Drawing.Size(100, 22);
            this.priceField.TabIndex = 13;
            // 
            // AdminPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1423, 661);
            this.Controls.Add(this.priceField);
            this.Controls.Add(this.menameField);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.DeleteProduct);
            this.Controls.Add(this.AddProduct);
            this.Controls.Add(this.buttonGetOrders);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonUsersInfo);
            this.Controls.Add(this.buttonDeleteRights);
            this.Controls.Add(this.buttonGiveRights);
            this.Controls.Add(this.LoginField);
            this.Controls.Add(this.buttonListAdmins);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "AdminPanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminPanel";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AdminPanel_FormClosed);
            this.Load += new System.EventHandler(this.AdminPanel_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button buttonListAdmins;
        private System.Windows.Forms.TextBox LoginField;
        private System.Windows.Forms.Button buttonGiveRights;
        private System.Windows.Forms.Button buttonDeleteRights;
        private System.Windows.Forms.Button buttonUsersInfo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonGetOrders;
        private System.Windows.Forms.Button AddProduct;
        private System.Windows.Forms.Button DeleteProduct;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.MaskedTextBox menameField;
        private System.Windows.Forms.MaskedTextBox priceField;
    }
}