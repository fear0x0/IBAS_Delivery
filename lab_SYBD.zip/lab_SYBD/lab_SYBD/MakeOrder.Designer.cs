﻿namespace lab_SYBD
{
    partial class MakeOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MakeOrder));
            this.checkBoxSemga = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.checkBoxMura = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.checkBoxMoloko = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.checkBoxTvorog = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.checkBoxSmetana = new System.Windows.Forms.CheckBox();
            this.SemgaCount = new System.Windows.Forms.MaskedTextBox();
            this.TvorogCount = new System.Windows.Forms.MaskedTextBox();
            this.SmetanaCount = new System.Windows.Forms.MaskedTextBox();
            this.IkraCount = new System.Windows.Forms.MaskedTextBox();
            this.PirogCount = new System.Windows.Forms.MaskedTextBox();
            this.TvorSirCount = new System.Windows.Forms.MaskedTextBox();
            this.SokCount = new System.Windows.Forms.MaskedTextBox();
            this.SlivMasloCount = new System.Windows.Forms.MaskedTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.checkBoxIkra = new System.Windows.Forms.CheckBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.checkBoxPirog = new System.Windows.Forms.CheckBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.checkBoxTvorSir = new System.Windows.Forms.CheckBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.checkBoxSok = new System.Windows.Forms.CheckBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.checkBoxMaslo = new System.Windows.Forms.CheckBox();
            this.label21 = new System.Windows.Forms.Label();
            this.AcceptOrder = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.MolokoCount = new System.Windows.Forms.MaskedTextBox();
            this.MuraCount = new System.Windows.Forms.MaskedTextBox();
            this.mySqlCommand1 = new MySqlConnector.MySqlCommand();
            this.SuspendLayout();
            // 
            // checkBoxSemga
            // 
            this.checkBoxSemga.AutoSize = true;
            this.checkBoxSemga.Location = new System.Drawing.Point(369, 91);
            this.checkBoxSemga.Name = "checkBoxSemga";
            this.checkBoxSemga.Size = new System.Drawing.Size(18, 17);
            this.checkBoxSemga.TabIndex = 1;
            this.checkBoxSemga.UseVisualStyleBackColor = true;
            this.checkBoxSemga.CheckedChanged += new System.EventHandler(this.checkBoxSemga_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(185, 96);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 18);
            this.label1.TabIndex = 2;
            this.label1.Text = "Количество: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(115, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "Сёмга";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(73, 153);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 18);
            this.label3.TabIndex = 6;
            this.label3.Text = "Муравейник";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(185, 153);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 18);
            this.label4.TabIndex = 5;
            this.label4.Text = "Количество: ";
            // 
            // checkBoxMura
            // 
            this.checkBoxMura.AutoSize = true;
            this.checkBoxMura.Location = new System.Drawing.Point(369, 155);
            this.checkBoxMura.Name = "checkBoxMura";
            this.checkBoxMura.Size = new System.Drawing.Size(18, 17);
            this.checkBoxMura.TabIndex = 4;
            this.checkBoxMura.UseVisualStyleBackColor = true;
            this.checkBoxMura.CheckedChanged += new System.EventHandler(this.checkBoxMura_CheckedChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(105, 222);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 18);
            this.label5.TabIndex = 9;
            this.label5.Text = "Молоко";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(185, 222);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 18);
            this.label6.TabIndex = 8;
            this.label6.Text = "Количество: ";
            // 
            // checkBoxMoloko
            // 
            this.checkBoxMoloko.AutoSize = true;
            this.checkBoxMoloko.Location = new System.Drawing.Point(369, 218);
            this.checkBoxMoloko.Name = "checkBoxMoloko";
            this.checkBoxMoloko.Size = new System.Drawing.Size(18, 17);
            this.checkBoxMoloko.TabIndex = 7;
            this.checkBoxMoloko.UseVisualStyleBackColor = true;
            this.checkBoxMoloko.CheckedChanged += new System.EventHandler(this.checkBoxMoloko_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(108, 273);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 18);
            this.label7.TabIndex = 12;
            this.label7.Text = "Творог";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(185, 273);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 18);
            this.label8.TabIndex = 11;
            this.label8.Text = "Количество: ";
            // 
            // checkBoxTvorog
            // 
            this.checkBoxTvorog.AutoSize = true;
            this.checkBoxTvorog.Location = new System.Drawing.Point(369, 272);
            this.checkBoxTvorog.Name = "checkBoxTvorog";
            this.checkBoxTvorog.Size = new System.Drawing.Size(18, 17);
            this.checkBoxTvorog.TabIndex = 10;
            this.checkBoxTvorog.UseVisualStyleBackColor = true;
            this.checkBoxTvorog.CheckedChanged += new System.EventHandler(this.checkBoxTvorog_CheckedChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(98, 327);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(69, 18);
            this.label9.TabIndex = 15;
            this.label9.Text = "Сметана";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(185, 323);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 18);
            this.label10.TabIndex = 14;
            this.label10.Text = "Количество: ";
            // 
            // checkBoxSmetana
            // 
            this.checkBoxSmetana.AutoSize = true;
            this.checkBoxSmetana.Location = new System.Drawing.Point(369, 322);
            this.checkBoxSmetana.Name = "checkBoxSmetana";
            this.checkBoxSmetana.Size = new System.Drawing.Size(18, 17);
            this.checkBoxSmetana.TabIndex = 13;
            this.checkBoxSmetana.UseVisualStyleBackColor = true;
            this.checkBoxSmetana.CheckedChanged += new System.EventHandler(this.checkBoxSmetana_CheckedChanged);
            // 
            // SemgaCount
            // 
            this.SemgaCount.Location = new System.Drawing.Point(282, 93);
            this.SemgaCount.Mask = "99";
            this.SemgaCount.Name = "SemgaCount";
            this.SemgaCount.Size = new System.Drawing.Size(65, 22);
            this.SemgaCount.TabIndex = 16;
            // 
            // TvorogCount
            // 
            this.TvorogCount.Location = new System.Drawing.Point(282, 270);
            this.TvorogCount.Mask = "99";
            this.TvorogCount.Name = "TvorogCount";
            this.TvorogCount.Size = new System.Drawing.Size(65, 22);
            this.TvorogCount.TabIndex = 19;
            // 
            // SmetanaCount
            // 
            this.SmetanaCount.Location = new System.Drawing.Point(282, 321);
            this.SmetanaCount.Mask = "99";
            this.SmetanaCount.Name = "SmetanaCount";
            this.SmetanaCount.Size = new System.Drawing.Size(65, 22);
            this.SmetanaCount.TabIndex = 20;
            // 
            // IkraCount
            // 
            this.IkraCount.Location = new System.Drawing.Point(917, 316);
            this.IkraCount.Mask = "99";
            this.IkraCount.Name = "IkraCount";
            this.IkraCount.Size = new System.Drawing.Size(65, 22);
            this.IkraCount.TabIndex = 40;
            // 
            // PirogCount
            // 
            this.PirogCount.Location = new System.Drawing.Point(917, 265);
            this.PirogCount.Mask = "99";
            this.PirogCount.Name = "PirogCount";
            this.PirogCount.Size = new System.Drawing.Size(65, 22);
            this.PirogCount.TabIndex = 39;
            // 
            // TvorSirCount
            // 
            this.TvorSirCount.Location = new System.Drawing.Point(917, 213);
            this.TvorSirCount.Mask = "99";
            this.TvorSirCount.Name = "TvorSirCount";
            this.TvorSirCount.Size = new System.Drawing.Size(65, 22);
            this.TvorSirCount.TabIndex = 38;
            // 
            // SokCount
            // 
            this.SokCount.Location = new System.Drawing.Point(917, 148);
            this.SokCount.Mask = "99";
            this.SokCount.Name = "SokCount";
            this.SokCount.Size = new System.Drawing.Size(65, 22);
            this.SokCount.TabIndex = 37;
            // 
            // SlivMasloCount
            // 
            this.SlivMasloCount.Location = new System.Drawing.Point(917, 88);
            this.SlivMasloCount.Mask = "99";
            this.SlivMasloCount.Name = "SlivMasloCount";
            this.SlivMasloCount.Size = new System.Drawing.Size(65, 22);
            this.SlivMasloCount.TabIndex = 36;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(691, 316);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(103, 18);
            this.label11.TabIndex = 35;
            this.label11.Text = "Икра красная";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(820, 318);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 18);
            this.label12.TabIndex = 34;
            this.label12.Text = "Количество: ";
            // 
            // checkBoxIkra
            // 
            this.checkBoxIkra.AutoSize = true;
            this.checkBoxIkra.Location = new System.Drawing.Point(1004, 317);
            this.checkBoxIkra.Name = "checkBoxIkra";
            this.checkBoxIkra.Size = new System.Drawing.Size(18, 17);
            this.checkBoxIkra.TabIndex = 33;
            this.checkBoxIkra.UseVisualStyleBackColor = true;
            this.checkBoxIkra.CheckedChanged += new System.EventHandler(this.checkBoxIkra_CheckedChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(740, 268);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(50, 18);
            this.label13.TabIndex = 32;
            this.label13.Text = "Пирог";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(820, 268);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(100, 18);
            this.label14.TabIndex = 31;
            this.label14.Text = "Количество: ";
            // 
            // checkBoxPirog
            // 
            this.checkBoxPirog.AutoSize = true;
            this.checkBoxPirog.Location = new System.Drawing.Point(1004, 267);
            this.checkBoxPirog.Name = "checkBoxPirog";
            this.checkBoxPirog.Size = new System.Drawing.Size(18, 17);
            this.checkBoxPirog.TabIndex = 30;
            this.checkBoxPirog.UseVisualStyleBackColor = true;
            this.checkBoxPirog.CheckedChanged += new System.EventHandler(this.checkBoxPirog_CheckedChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.Location = new System.Drawing.Point(678, 221);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(120, 18);
            this.label15.TabIndex = 29;
            this.label15.Text = "Творожный сыр";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(820, 217);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(100, 18);
            this.label16.TabIndex = 28;
            this.label16.Text = "Количество: ";
            // 
            // checkBoxTvorSir
            // 
            this.checkBoxTvorSir.AutoSize = true;
            this.checkBoxTvorSir.Location = new System.Drawing.Point(1004, 213);
            this.checkBoxTvorSir.Name = "checkBoxTvorSir";
            this.checkBoxTvorSir.Size = new System.Drawing.Size(18, 17);
            this.checkBoxTvorSir.TabIndex = 27;
            this.checkBoxTvorSir.UseVisualStyleBackColor = true;
            this.checkBoxTvorSir.CheckedChanged += new System.EventHandler(this.checkBoxTvorSir_CheckedChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.Location = new System.Drawing.Point(756, 148);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(36, 18);
            this.label17.TabIndex = 26;
            this.label17.Text = "Сок";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label18.Location = new System.Drawing.Point(820, 148);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(100, 18);
            this.label18.TabIndex = 25;
            this.label18.Text = "Количество: ";
            // 
            // checkBoxSok
            // 
            this.checkBoxSok.AutoSize = true;
            this.checkBoxSok.Location = new System.Drawing.Point(1004, 150);
            this.checkBoxSok.Name = "checkBoxSok";
            this.checkBoxSok.Size = new System.Drawing.Size(18, 17);
            this.checkBoxSok.TabIndex = 24;
            this.checkBoxSok.UseVisualStyleBackColor = true;
            this.checkBoxSok.CheckedChanged += new System.EventHandler(this.checkBoxSok_CheckedChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.Location = new System.Drawing.Point(664, 91);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(135, 18);
            this.label19.TabIndex = 23;
            this.label19.Text = "Сливочное масло";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label20.Location = new System.Drawing.Point(820, 91);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(100, 18);
            this.label20.TabIndex = 22;
            this.label20.Text = "Количество: ";
            // 
            // checkBoxMaslo
            // 
            this.checkBoxMaslo.AutoSize = true;
            this.checkBoxMaslo.Location = new System.Drawing.Point(1004, 86);
            this.checkBoxMaslo.Name = "checkBoxMaslo";
            this.checkBoxMaslo.Size = new System.Drawing.Size(18, 17);
            this.checkBoxMaslo.TabIndex = 21;
            this.checkBoxMaslo.UseVisualStyleBackColor = true;
            this.checkBoxMaslo.CheckedChanged += new System.EventHandler(this.checkBoxMaslo_CheckedChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.Location = new System.Drawing.Point(500, 29);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(85, 29);
            this.label21.TabIndex = 41;
            this.label21.Text = "Заказ";
            // 
            // AcceptOrder
            // 
            this.AcceptOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AcceptOrder.Location = new System.Drawing.Point(415, 438);
            this.AcceptOrder.Name = "AcceptOrder";
            this.AcceptOrder.Size = new System.Drawing.Size(282, 65);
            this.AcceptOrder.TabIndex = 42;
            this.AcceptOrder.Text = "Подтвердить";
            this.AcceptOrder.UseVisualStyleBackColor = true;
            this.AcceptOrder.Click += new System.EventHandler(this.AcceptOrder_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.Location = new System.Drawing.Point(22, 13);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(51, 29);
            this.label22.TabIndex = 43;
            this.label22.Text = "<---";
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // MolokoCount
            // 
            this.MolokoCount.Location = new System.Drawing.Point(282, 218);
            this.MolokoCount.Mask = "99";
            this.MolokoCount.Name = "MolokoCount";
            this.MolokoCount.Size = new System.Drawing.Size(65, 22);
            this.MolokoCount.TabIndex = 18;
            // 
            // MuraCount
            // 
            this.MuraCount.Location = new System.Drawing.Point(282, 153);
            this.MuraCount.Mask = "99";
            this.MuraCount.Name = "MuraCount";
            this.MuraCount.Size = new System.Drawing.Size(65, 22);
            this.MuraCount.TabIndex = 17;
            // 
            // mySqlCommand1
            // 
            this.mySqlCommand1.CommandTimeout = 0;
            this.mySqlCommand1.Connection = null;
            this.mySqlCommand1.Transaction = null;
            this.mySqlCommand1.UpdatedRowSource = System.Data.UpdateRowSource.None;
            // 
            // MakeOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1104, 541);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.AcceptOrder);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.IkraCount);
            this.Controls.Add(this.PirogCount);
            this.Controls.Add(this.TvorSirCount);
            this.Controls.Add(this.SokCount);
            this.Controls.Add(this.SlivMasloCount);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.checkBoxIkra);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.checkBoxPirog);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.checkBoxTvorSir);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.checkBoxSok);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.checkBoxMaslo);
            this.Controls.Add(this.SmetanaCount);
            this.Controls.Add(this.TvorogCount);
            this.Controls.Add(this.MolokoCount);
            this.Controls.Add(this.MuraCount);
            this.Controls.Add(this.SemgaCount);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.checkBoxSmetana);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.checkBoxTvorog);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.checkBoxMoloko);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.checkBoxMura);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkBoxSemga);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MakeOrder";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Go.Доставка";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MakeOrder_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox checkBoxSemga;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox checkBoxMura;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox checkBoxMoloko;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox checkBoxTvorog;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox checkBoxSmetana;
        private System.Windows.Forms.MaskedTextBox SemgaCount;
        private System.Windows.Forms.MaskedTextBox TvorogCount;
        private System.Windows.Forms.MaskedTextBox SmetanaCount;
        private System.Windows.Forms.MaskedTextBox IkraCount;
        private System.Windows.Forms.MaskedTextBox PirogCount;
        private System.Windows.Forms.MaskedTextBox TvorSirCount;
        private System.Windows.Forms.MaskedTextBox SokCount;
        private System.Windows.Forms.MaskedTextBox SlivMasloCount;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.CheckBox checkBoxIkra;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.CheckBox checkBoxPirog;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.CheckBox checkBoxTvorSir;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.CheckBox checkBoxSok;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.CheckBox checkBoxMaslo;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button AcceptOrder;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.MaskedTextBox MolokoCount;
        private System.Windows.Forms.MaskedTextBox MuraCount;
        private MySqlConnector.MySqlCommand mySqlCommand1;
    }
}